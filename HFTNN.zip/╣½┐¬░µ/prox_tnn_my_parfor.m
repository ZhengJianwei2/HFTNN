function [X,tnn,trank] = prox_tnn_my(Y,rho,fast)
[n1,n2,n3] = size(Y);
X = zeros(n1,n2,n3);
Y = fft(Y,[],3);
r2=2;
halfn3 = int16(n3/2 + 1);
tnn=0;
parfor i= 1:halfn3
     [U,S,V] = rsvd(Y(:,:,i),r2,2,2,1);
      S = diag(S);
      X(:,:,i)=U*diag(S)*V';
end
for j =n3:-1:halfn3+1
    X(:,:,j) = conj(X(:,:,n3-j+2));
end

    
    
    
    
X = ifft(X,[],3);
end

% randomized low rank SVD using QR of B^T version 
function [U,Sigma,V] = rsvd(A,k,p,q,s)
    m = size(A,1);
    n = size(A,2);
    l = k + p;

    R = randn(n,l);
    Y = A*R; 

    for j=1:q
        if mod(2*j-2,s) == 0
            [Y,~] = qr(Y,0);
        end
        Z = A'*Y;

        if mod(2*j-1,s) == 0
            [Z,~] = qr(Z,0);
        end
        Y = A*Z;
    end    
    [Q,~] = qr(Y,0);

    Bt = A'*Q;

    [Qhat,Rhat] = qr(Bt,0);
    
    [Uhat,Sigmahat,Vhat] = svd(Rhat,'econ');

    U = Q*Vhat;
    Sigma = Sigmahat;
    V = Qhat*Uhat;
    
    % take first k components
    U = U(:,1:k);
    Sigma = Sigma(1:k,1:k);
    V = V(:,1:k);
end
