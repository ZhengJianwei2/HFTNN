clear all
clc
for data_num=1:2
switch data_num
     case 1
         load 'pedestrian.mat'
    case 2
        load 'stefan.mat'
end
for a = [0.2]; % sampling rate
    %%
    % %���ص㶪ʧ

    img = img/max(img(:));
    [dimg,mask,r] = rempat(img,a);
      [m,n,p]=size(img);

%% %demo
   [recon_HFTNN] = Hankel_keams(dimg,mask);
    [recon_HFTNN] = rempat1(recon_HFTNN,r,p);
%% display results
PSNR_HFTNN = PSNR(recon_HFTNN,img);
SSIMvector =zeros(1,p);
for i=1:1:p
    J=255*img(:,:,i);
    I=255*recon_HFTNN(:,:,i); 
   [ SSIMvector(1,i),ssim_map] = ssim(J,I);
end
SSIM_Hankel=mean(SSIMvector );
disp(['PSNR_',num2str(a) ' = ',num2str(PSNR_HFTNN)]);
disp(['SSIM_',num2str(a) ' = ',num2str(SSIM_Hankel)]);
end
end
