function psnr = PSNR(Xfull,Xrecover)

% Written by Canyi Lu (canyilu@gmail.com)
maxP=1;
Xrecover = max(0,Xrecover);
Xrecover = min(1,Xrecover);
[n1,n2,n3] = size(Xrecover);
MSE = norm(Xfull(:)-Xrecover(:))^2/(n1*n2*n3);
psnr = 10*log10(maxP^2/MSE);