function [recon_HFTNN] = rempat1(recon_HFTNN,r,p)
recon_HFTNN=recon_HFTNN(:,:,r+1:p+r);
end