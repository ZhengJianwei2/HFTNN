function [dimg,mask,r] = rempat(img1,a)
r=3;
[m,n,p]=size(img1);
img=zeros(m,n,p+r+r);
[m1,n1,p1]=size(img);
img(:,:,1:r)=img1(:,:,1:r);
img(:,:,r+1:p+r)=img1(:,:,1:p);
img(:,:,p+r+1:p1)=img1(:,:,p-2:p);
mask=rand(m,n,p1);
mask(mask<a)=1;
mask((mask~=1))=0;
dimg=img.*mask;
end